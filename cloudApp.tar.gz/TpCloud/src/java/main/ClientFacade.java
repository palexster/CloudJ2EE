/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.Iterator;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author alex
 */
@Stateless
public class ClientFacade extends AbstractFacade<Client> {
    @PersistenceContext(unitName = "TpCloudPU")
    private EntityManager em;
    int dimension=1000;
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ClientFacade() {
        super(Client.class);
    }
    
    public void remplissage(){
        List<Client> all = this.findAll();
        Iterator<Client> it = all.iterator();
        while (it.hasNext()){
            this.remove(it.next());
        }
        int i=0;
        while(i<=dimension){
            Client c = new Client();
            c.setNom("Jean");
            c.setPrenom("Martin");
            this.create(c);
            i++;
        }
    }
    
}
