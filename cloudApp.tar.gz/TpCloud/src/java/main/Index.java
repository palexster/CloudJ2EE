/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

        
        
        
        
        
/**
 *
 * @author alex
 */
@WebServlet(name="Index",urlPatterns={"/Index"})
public class Index extends HttpServlet {
    @EJB
    ClientFacade clientFacade;

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Index</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Index at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            Connection con = null;
            Statement stmt = null;
            ResultSet rs;
            //clientFacade.remplissage();
            List<Client> tous = clientFacade.findAll();
            request.setAttribute("list", tous);
            String url = "list.jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
    }
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        clientFacade.remplissage();
        List<Client> tous = clientFacade.findAll();
            request.setAttribute("list", tous);
            String url = "list.jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
    }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

    
//    String serveraddress;
//        try {
//                Class.forName("com.mysql.jdbc.Driver");
//                    try {
//                        con =DriverManager.getConnection("jdbc:mysql://"+serveraddress+"/example","root","root");
//                    } catch (SQLException ex) {
//                        Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                stmt = con.createStatement();
//                rs = stmt.executeQuery("SELECT * FROM servlet");
//                // displaying records
//               } catch (SQLException e) {
//                    throw new ServletException("Servlet Could not display records.", e);
//                } catch (ClassNotFoundException e) {
//                    throw new ServletException("JDBC Driver not found.", e);
//                } finally {
//                    try {
//                      if(rs != null) {
//                            rs.close();
//                            rs = null;
//                        }
//                      if(stmt != null) {
//                            stmt.close();
//                            stmt = null;
//                        }
//                      if(con != null) {
//                            con.close();
//                            con = null;
//                        }
//                } catch (SQLException e) {}
//                }